package com.bryancorder.study_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
