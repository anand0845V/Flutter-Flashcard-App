class Constants {
  static const String Import = 'Import';
  static const String Restart = 'Restart';

  static const List<String> choices = <String>[
    Import,
    Restart,
  ];
}
