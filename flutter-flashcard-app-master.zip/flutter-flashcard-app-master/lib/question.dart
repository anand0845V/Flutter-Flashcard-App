class Question {
  String questionText;
  String questionAnswer;

  Question(this.questionText, this.questionAnswer);
}
