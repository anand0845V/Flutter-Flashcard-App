class Score {
  int questionIndex;
  bool correct;

  Score(this.questionIndex, this.correct);
}
